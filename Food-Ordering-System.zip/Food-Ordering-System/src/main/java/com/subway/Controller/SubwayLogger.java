package com.subway.Controller;
import org.apache.log4j.Logger;

public class SubwayLogger {


		public static final Logger FILE_LOGGER=Logger.getLogger("FILE_LOGGER");
		


}
