package com.subway.model;

public class OrderBean {
int orderid;
String cname;
String iname;
int cost;
String type;
String topping;
String extracheese;
int quantity;
int itemtotal;
public int getOrderid() {
	return orderid;
}
public void setOrderid(int orderid) {
	this.orderid = orderid;
}

public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getIname() {
	return iname;
}
public void setIname(String iname) {
	this.iname = iname;
}
public int getCost() {
	return cost;
}
public void setCost(int cost) {
	this.cost = cost;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getTopping() {
	return topping;
}
public void setTopping(String topping) {
	this.topping = topping;
}
public String getExtracheese() {
	return extracheese;
}
public void setExtracheese(String extracheese) {
	this.extracheese = extracheese;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public int getItemtotal() {
	return itemtotal;
}
public void setItemtotal(int itemtotal) {
	this.itemtotal = itemtotal;
}

}
